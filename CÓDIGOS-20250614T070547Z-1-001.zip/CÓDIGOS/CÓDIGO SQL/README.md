
# Proyecto MIMIC-IV en PostgreSQL: Diabetes Tipo 1

Este repositorio contiene todos los scripts necesarios para crear una base de datos en PostgreSQL a partir del módulo hospitalario de MIMIC-IV, con un enfoque especial en pacientes con Diabetes Mellitus Tipo 1.

---

## 📁 Estructura del repositorio

```
mimi-postgres-setup/
├── mimi_hosp_schema.sql           # Esquema completo hospitalario con claves primarias y foráneas
├── mimi_diabetic_schema.sql       # Esquema con pacientes diabéticos tipo 1
├── load_data.sql                  # Script para cargar datos desde archivos CSV
└── README.md                      # Este archivo
```

---

## 🧰 Requisitos

- PostgreSQL
- Acceso a los datos de MIMIC-IV (módulo `hosp`)
- Herramienta de carga como `psql` o DBeaver
- Variables de entorno opcionales: `data_dir` con la ruta a los CSV

---

## 🔧 Pasos para la instalación

### 1. Crear base de datos y esquemas

```bash
psql -U <usuario> -d postgres -c "CREATE DATABASE mimi;"
psql -U <usuario> -d mimi -f mimi_hosp_schema.sql
```

### 2. Cargar los datos

```bash
psql -U <usuario> -d mimi -v data_dir='/ruta/a/csvs' -f load_data.sql
```

### 3. Crear esquema filtrado con pacientes DM1

```bash
psql -U <usuario> -d mimi -f mimi_diabetic_schema.sql
```

---

## 🩺 Criterios clínicos para filtrar pacientes con DM1

- Códigos ICD-9: `250.01`, `250.03` (diabetes mellitus tipo 1 sin y con complicaciones)
- Códigos ICD-10: `E10%`
- Se excluyen pacientes con otros tipos de diabetes si aparecen en el mismo episodio

---

## 📌 Notas adicionales

- Las tablas en `mimi_diabetic` contienen solo los registros vinculados a pacientes DM1
- La tabla `diabetic_patients_ids` permite una trazabilidad clara
- Todas las relaciones entre tablas se mantienen para permitir análisis longitudinales

---

## 🧑‍💻 Autoría

Desarrollado por Ana Quintanilla como parte del TFM sobre optimización del seguimiento de pacientes con diabetes tipo 1 y predicción de insuficiencia renal con MIMIC-IV.
