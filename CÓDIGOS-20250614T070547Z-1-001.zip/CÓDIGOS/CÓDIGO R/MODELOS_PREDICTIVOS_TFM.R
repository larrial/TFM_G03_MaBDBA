### MODELOS PREDICTIVOS


## --------------------------------------------------------------------------------
#REGRESIÓN LOGÍSTICA - MODELO PREDICTIVO I TÉSIS FINAL CON CURVA LIFT

## ----setup, include=FALSE---------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(warning = FALSE)
options(warn = -1)  # Desactiva las advertencias

## ---------------------------------------------------------------------------------------------------------------------------------------
library(themis)
suppressPackageStartupMessages(library("tidymodels"))
tidymodels_prefer()

## ---------------------------------------------------------------------------------------------------------------------------------------
library(readxl)
dataset <- read_excel("/Users/laurariera/Desktop/TFM/dataset_features.xlsx")

## ---------------------------------------------------------------------------------------------------------------------------------------
#TRANSFORMACIÓN VARIABLES DATASET COMPLETO
### 2.1-Variables binarias ----------------------------------------------------------------
# Lista de variables a convertir en binarias
dataset <- dataset |>
  mutate(toma_iron_supplements = as.factor(ifelse(toma_iron_supplements == 1, 1, 0))) # 1 si toma suplementos iron, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_cardiovascular = as.factor(ifelse(toma_cardiovascular == 1, 1, 0))) # 1 si toma cardiovascular, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_renal = as.factor(ifelse(toma_renal == 1, 1, 0))) # 1 si toma renal, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_corticosteroid = as.factor(ifelse(toma_corticosteroid == 1, 1, 0))) # 1 si toma corticosteroides, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_diuretic = as.factor(ifelse(toma_diuretic == 1, 1, 0))) # 1 si toma diurético, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_vasodilator = as.factor(ifelse(toma_vasodilator == 1, 1, 0))) # 1 si toma vasodilatador, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_vasopressor = as.factor(ifelse(toma_vasopressor == 1,1, 0))) # 1 si toma vasopresor, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_anesthetic = as.factor(ifelse(toma_anesthetic == 1, 1, 0))) # 1 si toma anestésico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_supplement = as.factor(ifelse(toma_supplement == 1, 1, 0))) # 1 si toma suplemento, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_antipsychotic = as.factor(ifelse(toma_antipsychotic == 1, 1, 0))) # 1 si toma antipsicótico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_proton_pump_inhibitor = as.factor(ifelse(toma_proton_pump_inhibitor == 1, 1, 0))) # 1 si toma inhibidor de bomba de protones, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_urological = as.factor(ifelse(toma_urological == 1, 1, 0))) # 1 si toma medicamento urológico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_immunosuppressant = as.factor(ifelse(toma_immunosuppressant == 1, 1, 0))) # 1 si toma inmunosupresor, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_sedative = as.factor(ifelse(toma_sedative == 1, 1, 0))) # 1 si toma sedante, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_antihistamine = as.factor(ifelse(toma_antihistamine == 1,1, 0))) # 1 si toma antihistamínico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_h2_antihistamine = as.factor(ifelse(toma_h2_antihistamine ==  1,1, 0))) # 1 si toma antihistamínico H2, 0 en caso contrario
dataset <- dataset |>
  mutate(Antagonist = as.factor(ifelse(Antagonist == 1, 1, 0))) # 1 si toma antagonista, 0 en caso contrario
dataset <- dataset |>
  mutate(Antiflatulent = as.factor(ifelse(Antiflatulent == 1, 1, 0))) # 1 si toma antiflatulento, 0 en caso contrario
dataset <- dataset |>
  mutate(Antiseptic = as.factor(ifelse(Antiseptic == 1, 1, 0))) # 1 si toma antiséptico, 0 en caso contrario
dataset <- dataset |>
  mutate(Antitussive = as.factor(ifelse(Antitussive == 1, 1, 0))) # 1 si toma antitusígeno, 0 en caso contrario
dataset <- dataset |>
  mutate(Laxative = as.factor(ifelse(Laxative == 1, 1, 0))) # 1 si toma laxante, 0 en caso contrario
dataset <- dataset |>
  mutate(`Opioid Agonist-Antagonist` = as.factor(ifelse(`Opioid Agonist-Antagonist` == 1, 1, 0))) # 1 si toma agonista-antagonista opioide, 0 en caso contrario
dataset <- dataset |>
  mutate(Radiology = as.factor(ifelse(Radiology == 1, 1, 0))) # 1 si toma radiología, 0 en caso contrario
dataset <- dataset |>
  mutate(Respiratory = as.factor(ifelse(Respiratory == 1, 1, 0))) # 1 si toma respiratorio, 0 en caso contrario
dataset <- dataset |>
  mutate(`Smoking cessation` = as.factor(ifelse(`Smoking cessation` == 1, 1, 0))) # 1 si toma para dejar de fumar, 0 en caso contrario
dataset <- dataset |>
  mutate(Vaccine = as.factor(ifelse(Vaccine == 1, 1, 0))) # 1 si toma vacuna, 0 en caso contrario
dataset <- dataset |>
  mutate(Cardiología = as.factor(ifelse(Cardiología == 1, 1, 0))) # 1 si toma medicamentos de cardiología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Cirugía / Procedimientos Médicos` = as.factor(ifelse(`Cirugía / Procedimientos Médicos` == 1, 1, 0))) # 1 si toma medicamentos para cirugía, 0 en caso contrario
dataset <- dataset |>
  mutate(`Enfermedades Infecciosas` = as.factor(ifelse(`Enfermedades Infecciosas` == 1, 1, 0))) # 1 si toma medicamentos para enfermedades infecciosas, 0 en caso contrario
dataset <- dataset |>
  mutate(`Factores Sociales / Exposición / Historial` = as.factor(ifelse(`Factores Sociales / Exposición / Historial` == 1, 1, 0))) # 1 si tiene factores sociales/exposición/historial relevante, 0 en caso contrario
dataset <- dataset |>
  mutate(`Gastroenterología / Digestivo` = as.factor(ifelse(`Gastroenterología / Digestivo` == 1, 1, 0))) # 1 si toma medicamentos de gastroenterología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Metabólicas Y Nutricionales` = as.factor(ifelse(`Metabólicas Y Nutricionales` == 1, 1, 0))) # 1 si toma medicamentos metabólicos o nutricionales, 0 en caso contrario
dataset <- dataset |>
  mutate(Nefrología = as.factor(ifelse(Nefrología == 1, 1, 0))) # 1 si toma medicamentos de nefrología, 0 en caso contrario
dataset <- dataset |>
  mutate(Neumología = as.factor(ifelse(Neumología == 1, 1, 0))) # 1 si toma medicamentos de neumología, 0 en caso contrario
dataset <- dataset |>
  mutate(Oncología = as.factor(ifelse(Oncología == 1, 1, 0))) # 1 si toma medicamentos oncológicos, 0 en caso contrario
dataset <- dataset |>
  mutate(Reumatología = as.factor(ifelse(Reumatología == 1, 1, 0))) # 1 si toma medicamentos de reumatología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Salud Mental Y Neurológica` = as.factor(ifelse(`Salud Mental Y Neurológica` == 1, 1, 0))) # 1 si toma medicamentos para salud mental/neurología, 0 en caso contrario
dataset <- dataset |>
  mutate(murio = as.factor(ifelse(murio == 1, 1, 0))) # 1 si la persona ha muerto, 0 en caso contrario
dataset <- dataset |>
  mutate(gender = as.factor(ifelse(gender == "F", 1, 0))) # 1 si la persona es mujer, 0 si es hombre


### 2.2-Variables ordinales --------------------------------------------------------------------------------------------------------------------------
# Variables categóricas ordinales (con orden)

dataset <- dataset |>
  mutate(Analgesic_class = factor(Analgesic_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antibiotic_class = factor(Antibiotic_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Anticoagulant_class = factor(Anticoagulant_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antidepressant_class = factor(Antidepressant_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antihypertensive_class = factor(Antihypertensive_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antiplatelet_class = factor(Antiplatelet_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Electrolyte_class = factor(Electrolyte_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Fluid & Electrolyte_class` = factor(`Fluid & Electrolyte_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Lipid-lowering_class` = factor(`Lipid-lowering_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Endocrine & Metabolic_class` = factor(`Endocrine & Metabolic_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 


### Variable target binaria------------------------------------------------------------------------------------------------------------------------------------------------------------------------
dataset <- dataset |>
  mutate(`Insuficiencia Renal` = as.factor(ifelse(`Insuficiencia Renal` == 1, 1, 0)))

### Descripciones estadísticas-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
head (dataset)
str (dataset)
summary (dataset)
colnames(dataset)

### lo de la edad-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
dataset <- dataset %>%
  mutate(anchor_age = as.numeric(anchor_age))  # Convertir a numérico si no lo es ya

dataset <- dataset %>%
  mutate(anchor_age = case_when(
    anchor_age >= 18 & anchor_age < 25 ~ "[18-25)", 
    anchor_age >= 25 & anchor_age < 35 ~ "[25-35)", 
    anchor_age >= 35 & anchor_age < 45 ~ "[35-45)", 
    anchor_age >= 45 & anchor_age < 55 ~ "[45-55)", 
    anchor_age >= 55 & anchor_age < 65 ~ "[55-65)", 
    anchor_age >= 65 & anchor_age <= 75 ~ "[65-75]", 
    TRUE ~ NA_character_  # Si hay valores fuera de estos rangos, los marcamos como NA
  ))
# Verificar los resultados después de la conversión
table(dataset$anchor_age)

# Convertir a factor con los niveles correctos
dataset <- dataset %>%
  mutate(anchor_age = factor(anchor_age, levels = c("[18-25)", "[25-35)", "[35-45)", "[45-55)", 
                                                    "[55-65)", "[65-75]"), ordered = TRUE))




### Subconjuntos preparación PCA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Seleccionar variables relevantes medicacion
selected_vars <- c("Antagonist", "Antiflatulent", "Antiseptic", "Antitussive", "Laxative", "Opioid Agonist-Antagonist", "Radiology", "Respiratory", "Smoking cessation", "Vaccine", "toma_iron_supplements", "toma_cardiovascular", "toma_renal", "toma_corticosteroid", "toma_diuretic", "toma_vasodilator", "toma_vasopressor", "toma_anesthetic", "toma_supplement", "toma_antipsychotic", "toma_proton_pump_inhibitor", "toma_urological", "toma_immunosuppressant", "toma_sedative", "toma_antihistamine", "toma_h2_antihistamine", "Analgesic_class", "Antibiotic_class", "Anticoagulant_class", "Antidepressant_class", "Antihypertensive_class", "Antiplatelet_class", "Electrolyte_class", "Fluid & Electrolyte_class", "Lipid-lowering_class", "Endocrine & Metabolic_class")
# Crear un subset de datos
dataset_medicacion_subset <- dataset |>
  select(all_of(selected_vars))
str(dataset_medicacion_subset)

# Seleccionar variables relevantes comorbidades
selected_vars <- c("Cardiología", "Cirugía / Procedimientos Médicos", "Enfermedades Infecciosas", "Factores Sociales / Exposición / Historial", "Gastroenterología / Digestivo", "Insuficiencia Renal", "Metabólicas Y Nutricionales", "Nefrología", "Neumología", "Oncología", "Reumatología", "Salud Mental Y Neurológica")
# Crear un subset de datos
dataset_comorbidades_subset <- dataset |>
  select(all_of(selected_vars))
str(dataset_comorbidades_subset)

# Seleccionar variables relevantes pruebas médicas
selected_vars <- c("Anion Gap-Blood-Chemistry", "Bicarbonate-Blood-Chemistry", "Calcium, Total-Blood-Chemistry", "Chloride-Blood-Chemistry", "Glucose-Blood-Chemistry", "Hematocrit-Blood-Hematology", "Hemoglobin-Blood-Hematology", "MCH-Blood-Hematology", "MCHC-Blood-Hematology", "MCV-Blood-Hematology", "Magnesium-Blood-Chemistry", "Phosphate-Blood-Chemistry", "Platelet Count-Blood-Hematology", "Potassium-Blood-Chemistry", "RDW-Blood-Hematology", "Red Blood Cells-Blood-Hematology", "Sodium-Blood-Chemistry", "White Blood Cells-Blood-Hematology", "eGFR", "BUN/Creatinina")
# Crear un subset de datos
dataset_pruebas_subset <- dataset |>
  select(all_of(selected_vars))
str(dataset_pruebas_subset)

str(dataset)
#1-Fijar semilla y splitting-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
suppressPackageStartupMessages(library("tidymodels"))
set.seed(123)  # Semilla para dividir en training y test
data_split <- rsample::initial_split(dataset, prop = 0.7)
data_train <- rsample::training(data_split)
data_test <- rsample::testing(data_split)

###COMPROBAMOS CORRELACIONES DE LOS SUBCONJUNTOS ------------------------------------------------------------------------------------------------
#si las variables predictoras estan muy correlacionadas entre ellas, se puede reducir la dimension del espacio de features realizando un pca.

##subconjunto medicacion  ------------------------------------------------------------------
# 1. Creamos una copia temporal del dataset
dataset_temp <- dataset_medicacion_subset
# 2. Convertir factores binarios y ordinales a valores numéricos solo en la copia temporal
dataset_temp <- dataset_temp %>%
  mutate(across(where(is.factor), ~ as.numeric(as.character(.)))) %>%
  mutate(across(where(is.ordered), ~ as.numeric(as.character(.))))
# 3. Calcular la matriz de correlación solo para las variables numéricas
correlacion <- cor(dataset_temp)
print(correlacion)

# Calcular la matriz de correlación usando Spearman
correlacion_spearman <- cor(dataset_temp, method = "spearman")
print(correlacion_spearman)
# Verificar las correlaciones fuertes (mayores a 0.7 o menores a -0.7)
correlaciones_fortalezas <- correlacion_spearman[abs(correlacion_spearman) > 0.7]
print(correlaciones_fortalezas)
# Calcular el determinante de la matriz de correlación
det(correlacion_spearman)

#El valor 6.024728e-12 para el determinante de la matriz de correlación es un valor extremadamente pequeño, cercano a 0. 
#Este valor es significativo porque sugiere que muchas de las variables en tu conjunto de datos están altamente correlacionadas entre sí.


library(corrplot)
library(reshape2)

importancia_variables <- apply(correlacion_spearman, 1, function(x) mean(abs(x), na.rm = TRUE))
cor_melted <- melt(correlacion_spearman)
cor_melted$importance <- rep(importancia_variables, each = nrow(correlacion_spearman))
ggplot(cor_melted, aes(Var1, Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "#ADD8E6", high = "#808000", mid = "white", midpoint = 0) +  # Azul clarito a oliva
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  labs(title = "Mapa de Calor Correlación Spearman Subconjunto Medicación", 
       x = "Variables", 
       y = "Variables", 
       fill = "Correlación") +
  geom_text(aes(label = round(importance, 2)), color = "black", size = 3) 



##subconjunto pruebas médicas ------------------------------------------------------------------ 
dataset_temp <- dataset_pruebas_subset
# 2. Convertir factores binarios y ordinales a valores numéricos solo en la copia temporal
dataset_temp <- dataset_temp %>%
  mutate(across(where(is.factor), ~ as.numeric(as.character(.)))) %>%
  mutate(across(where(is.ordered), ~ as.numeric(as.character(.))))
# 3. Calcular la matriz de correlación solo para las variables numéricas
correlacion <- cor(dataset_temp)
print(correlacion)

# Calcular la matriz de correlación usando Spearman
correlacion_spearman <- cor(dataset_temp, method = "spearman")
print(correlacion_spearman)
# Verificar las correlaciones fuertes (mayores a 0.7 o menores a -0.7)
correlaciones_fortalezas <- correlacion_spearman[abs(correlacion_spearman) > 0.7]
print(correlaciones_fortalezas)
# Calcular el determinante de la matriz de correlación
det(correlacion_spearman)


library(corrplot)
library(reshape2)

importancia_variables <- apply(correlacion_spearman, 1, function(x) mean(abs(x), na.rm = TRUE))
cor_melted <- melt(correlacion_spearman)
cor_melted$importance <- rep(importancia_variables, each = nrow(correlacion_spearman))
ggplot(cor_melted, aes(Var1, Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "#ADD8E6", high = "#808000", mid = "white", midpoint = 0) +  # Azul clarito a oliva
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  labs(title = "Mapa de Calor Correlación Spearman Subconjunto Pruebas Médicas", 
       x = "Variables", 
       y = "Variables", 
       fill = "Correlación") +
  geom_text(aes(label = round(importance, 2)), color = "black", size = 3)




##subconjunto comorbidades  ------------------------------------------------------------------
dataset_temp <- dataset_comorbidades_subset
# 2. Convertir factores binarios y ordinales a valores numéricos solo en la copia temporal
dataset_temp <- dataset_temp %>%
  mutate(across(where(is.factor), ~ as.numeric(as.character(.)))) %>%
  mutate(across(where(is.ordered), ~ as.numeric(as.character(.))))
# 3. Calcular la matriz de correlación solo para las variables numéricas
correlacion <- cor(dataset_temp)
print(correlacion)

# Calcular la matriz de correlación usando Spearman
correlacion_spearman <- cor(dataset_temp, method = "spearman")
print(correlacion_spearman)
# Verificar las correlaciones fuertes (mayores a 0.7 o menores a -0.7)
correlaciones_fortalezas <- correlacion_spearman[abs(correlacion_spearman) > 0.7]
print(correlaciones_fortalezas)
# Calcular el determinante de la matriz de correlación
det(correlacion_spearman)

library(corrplot)
library(reshape2)

importancia_variables <- apply(correlacion_spearman, 1, function(x) mean(abs(x), na.rm = TRUE))
cor_melted <- melt(correlacion_spearman)
cor_melted$importance <- rep(importancia_variables, each = nrow(correlacion_spearman))
ggplot(cor_melted, aes(Var1, Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "#ADD8E6", high = "#808000", mid = "white", midpoint = 0) +  # Azul clarito a oliva
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  labs(title = "Mapa de Calor Correlación Spearman Subconjunto Comorbidades", 
       x = "Variables", 
       y = "Variables", 
       fill = "Correlación") +
  geom_text(aes(label = round(importance, 2)), color = "black", size = 3)



#2-Receta---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
rec_reg_tune <- recipe(`Insuficiencia Renal`~ ., data = data_train) |> 
  update_role(patient_id, new_role = "none") |> 
  # Eliminar predictores con baja varianza
  recipes::step_nzv(all_predictors()) |>  
  # Omitir valores faltantes en variables numéricas
  recipes::step_naomit(all_numeric_predictors()) |> 
  # Agrupar categorías poco frecuentes
  recipes::step_other(all_nominal_predictors(), threshold = 0.01) |>  
  # Transformar categóricas en dummies
  recipes::step_dummy(all_nominal_predictors(), one_hot = FALSE) |> 
  # Eliminar predictores con baja varianza
  recipes::step_nzv(all_predictors()) |>  #acabo de añadir este step para eliminar las variables con poca varianza despues de hacer los dummies 
  # Transformar numéricas para simetría
  recipes::step_BoxCox(all_numeric_predictors()) |>  
  # Normalizar variables numéricas
  recipes::step_normalize(all_numeric_predictors())  |>  
  # Empleamos pca - componentes princiaples
  step_pca(all_numeric_predictors(), threshold = 0.9) 

receta_prep <- rec_reg_tune %>% prep()
datos_pca <- receta_prep %>% bake(new_data = NULL)
datos_pca

## PREDECIMOS EL MODELO CON LA REGRESION LOGÍSTICA--------------------------------------------------------------------------------------------------------

install.packages("dplyr")                       
library("dplyr") 
library(MASS)

dim(data_train) # dimension/shape of train dataset
dim(data_test)  # dimension/shape of test dataset
head(data_train)
head(data_test)

library(tidymodels)
library(ggplot2)
tidymodels_prefer()


# 3. Modelo: regresión logística
log_model <- logistic_reg() |> 
  set_engine("glm")

# 4. Workflow
wf <- workflow() |> 
  add_model(log_model) |> 
  add_recipe(rec_reg_tune)

# 5. Ajustar modelo con train
fit_model <- fit(wf, data = data_train)

# 6. Predicciones probabilísticas en training
pred_train <- predict(fit_model, data_train, type = "prob") |>
  bind_cols(data_train)

# 7. Calcular curva ROC y umbral óptimo (Youden)
roc_train <- roc_curve(pred_train, truth = `Insuficiencia Renal`, `.pred_1`, event_level = "second") |>
  mutate(youden = sensitivity + specificity - 1)

umbral_optimo <- roc_train |> 
  filter(youden == max(youden)) |> 
  pull(.threshold)

# 8. Aplicar umbral a training
pred_train <- pred_train |>
  mutate(clase_ajustada = factor(ifelse(.pred_1 >= umbral_optimo, "1", "0"), levels = c("0", "1")),
         `Insuficiencia_Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1")))

# 9. Métricas para training
metricas <- metric_set(accuracy, sens, specificity, precision, f_meas, detection_prevalence, j_index)
metricas_train <- pred_train |> metricas(truth = `Insuficiencia_Renal`, estimate = clase_ajustada, event_level = "second")
auc_train <- pred_train |> roc_auc(truth = `Insuficiencia Renal`, `.pred_1`, event_level = "second")
metricas_train <- bind_rows(metricas_train, auc_train)

# 10. Predicciones en test con umbral fijo
pred_test <- predict(fit_model, data_test, type = "prob") |>
  bind_cols(data_test) |>
  mutate(clase_ajustada = factor(ifelse(`.pred_1` >= umbral_optimo, "1", "0"), levels = c("0", "1")),
         `Insuficiencia Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1")))

# 11. Métricas para test
metricas_test <- pred_test |> metricas(truth = `Insuficiencia Renal`, estimate = clase_ajustada, event_level = "second")
auc_test <- pred_test |> roc_auc(truth = `Insuficiencia Renal`, `.pred_1`, event_level = "second")
metricas_test <- bind_rows(metricas_test, auc_test)

# 12. Mostrar resultados
cat("Métricas en TRAIN con umbral ajustado:\n")
print(metricas_train)
cat("\nMétricas en TEST con umbral ajustado:\n")
print(metricas_test)

# 13. Visualización ROC
roc_curve_train <- roc_curve(pred_train, truth = `Insuficiencia Renal`, `.pred_1`, event_level = "second")
roc_curve_test <- roc_curve(pred_test, truth = `Insuficiencia Renal`, `.pred_1`, event_level = "second")

ggplot() +
  geom_line(data = roc_curve_train, aes(x = 1 - specificity, y = sensitivity, color = "Train"), 
            color = "#808000") +  # Oliva
  geom_line(data = roc_curve_test, aes(x = 1 - specificity, y = sensitivity, color = "Test"), 
            color = "#ADD8E6") +  # Azul clarita
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "gray") +
  labs(title = sprintf("Curvas ROC - Train (AUC: %.3f), Test (AUC: %.3f)", auc_train$.estimate, auc_test$.estimate),
       x = "1 - Especificidad",
       y = "Sensibilidad",
       color = "Datos") +
  theme_minimal()

#### CURVA LIFT MODELO REGRESIÓN LOGÍSTICA ####--------------------------------------------------------------------------------------------------------

library(dplyr)
library(ggplot2)

# 1. Ordenar predicciones en test de mayor a menor probabilidad de clase positiva
pred_test_lift <- pred_test %>%
  arrange(desc(.pred_1)) %>%
  mutate(rank = row_number(),
         total = n(),
         percentile = ntile(rank, 10))  #calculamos deciles sobre el score.
#dividimos el ranking en 10 grupos iguales del 10% mas alto al mas bajo.

# 2. Calcular tasa positiva global (baseline)
baseline_rate <- mean(as.numeric(as.character(pred_test_lift$`Insuficiencia Renal`))) #sacamos vector de reales. Se convierten a numericos para facilitar el calculo


# 3. Calcular tasa positiva por decil y comparamos con tasa base
lift_df <- pred_test_lift %>%
  group_by(percentile) %>%
  summarise(
    n_obs = n(),
    positives = sum(as.numeric(as.character(`Insuficiencia Renal`))),
    positive_rate = positives / n_obs) %>%
  mutate(lift = positive_rate / baseline_rate,
         percentile_label = percentile * 10)  # para mostrar %

# 4. Graficar curva lift
ggplot(lift_df, aes(x = percentile_label, y = lift)) +
  geom_line() +
  geom_point() +
  geom_hline(yintercept = 1, linetype = "dashed", color = "red") + #es la linea base
  labs(
    title = "CURVA LIFT MODELO REGRESIÓN LOGÍSTICA APLICANDO PCA",
    x = "Percentil acumulado (%)",
    y = "Lift (Ratio tasa positiva / tasa base)"
  ) +
  theme_minimal()



##------------------------------------------------------------------------------------------------------------------------------------

## WORKFLOW 1: LASSO---------------------------------------------------------------------
#1. FIJAMOS SEMILLA---------------------------------------------------------------------
suppressPackageStartupMessages(library("tidymodels"))
set.seed(123)  # Semilla para dividir en training y test
data_split <- rsample::initial_split(dataset, prop = 0.7)
data_train <- rsample::training(data_split)
data_test <- rsample::testing(data_split)

#2. receta---------------------------------------------------------------------

rec_reg_tune <- recipe(`Insuficiencia Renal`~ ., data = data_train) |> 
  update_role(patient_id, new_role = "none") |> 
  # Eliminar predictores con baja varianza
  recipes::step_nzv(all_predictors()) |>  
  # Omitir valores faltantes en variables numéricas
  recipes::step_naomit(all_numeric_predictors()) |> 
  # Agrupar categorías poco frecuentes
  recipes::step_other(all_nominal_predictors(), threshold = 0.01) |>  
  # Transformar categóricas en dummies
  recipes::step_dummy(all_nominal_predictors(), one_hot = FALSE) |> 
  # Eliminar predictores con baja varianza
  recipes::step_nzv(all_predictors()) |>  #acabo de añadir este step para eliminar las variables con poca varianza despues de hacer los dummies 
  # Transformar numéricas para simetría
  recipes::step_BoxCox(all_numeric_predictors()) |>  
  # Normalizar variables numéricas
  recipes::step_normalize(all_numeric_predictors())  

#----------------------------------------------------------------------------------------------------------------------------------

# Modelo de regresión logística con tuning para LASSO 
logistic_lasso_model_tune <- logistic_reg(penalty = tune(), mixture = 1) |>
  set_engine("glmnet") |>  # Usar glmnet para soporte de regularización
  set_mode("classification")  # Configurar modo clasificación

# Configurar el flujo de trabajo
wflow_lasso_tune <- workflow() |>
  add_model(logistic_lasso_model_tune) |>
  add_recipe(rec_reg_tune)

# Tunear e inicializar parámetros
param_tuning_lasso <- wflow_lasso_tune |>
  extract_parameter_set_dials()

# Rango de valores tuneados
grid_lasso_tune <- grid_max_entropy(param_tuning_lasso, size = 100)

wflow_lasso_tune

## ---------------------------------------------------------------------------------------------------------------------------------------
library(parallel)
library(doParallel)
set.seed(101112) # Semilla para validación cruzada
k1 <- 5; k2 <- 10
data_cvrep <- rsample::vfold_cv(data_train, v = k1, repeats = k2)
metricas <- metric_set(accuracy, sens, spec, precision, f_meas, detection_prevalence, roc_auc,j_index)

#Validación cruzada con los distintos workflows para estimar los mejores hiperparametros:
ctrl <- control_resamples(event_level = "second") 
cl <- makePSOCKcluster(4)
registerDoParallel(cl)

#LASSO ------------------------------------------------------------------------------------------------------------------------
lasso_reg_tune <- tune_grid(wflow_lasso_tune,
                            resamples = data_cvrep,
                            grid = grid_lasso_tune,
                            metrics = metricas,
                            control=ctrl)

stopCluster(cl)


## ----warning=FALSE----------------------------------------------------------------------------------------------------------------------
#Selección del hiperparámetro con mejor F1 score
##LASSO---------------------------------------------------------------
# Mostrar y seleccionar el mejor modelo
lasso_reg_tune |>
  show_best(metric = "roc_auc")
best_lasso_reg_tune <- lasso_reg_tune |>
  select_best(metric = "roc_auc")


# Filtrar las métricas correspondientes a los mejores hiperparámetros
lasso_metrics_best <- lasso_reg_tune |>
  collect_metrics() |> 
  filter(penalty == best_lasso_reg_tune$penalty)

# Mostrar las métricas
print(lasso_metrics_best)

# Finalizar el workflow con los mejores hiperparámetros
finalwf_lasso <- wflow_lasso_tune |>
  finalize_workflow(best_lasso_reg_tune)
#finalwf_lasso


## ----warning=FALSE----------------------------------------------------------------------------------------------------------------------
# Crear nuevo esquema de validación cruzada
set.seed(202201)
data_cvrep_new <- rsample::vfold_cv(data_train, v = 5, repeats = 10)
ctrl <- control_grid(event_level = "second") 
cl <- makePSOCKcluster(4)
registerDoParallel(cl)

##LASSO-------------------------------------------
# Evaluar el modelo final con la nueva validación cruzada
final_lasso_cv <- fit_resamples(
  finalwf_lasso,
  resamples = data_cvrep_new,
  metrics = metricas,
  control = ctrl)

# Recopilar métricas
metrics_final_lasso <- collect_metrics(final_lasso_cv)

print(metrics_final_lasso)


######## PARA MÉTRICAS TEST Y TRAINING CON UMBRAL AJUSTADO LASSO ################################################    
## ---------------------------------------------------------------------------------------------------------------------------------------
# Realizo el training con nuestro valor de lambda, para luego predecir con el test

umbral_optimo <- 0.2434532
ctrl = control_last_fit(event_level = "second")

modelo_final <- fit(finalwf_lasso, data = data_train)

# 2. Predicciones sobre TRAIN
predicciones_train <- predict(modelo_final, data_train, type = "prob") |> 
  bind_cols(data_train) |> 
  mutate(
    clase_ajustada = factor(ifelse(.pred_1 >= umbral_optimo, "1", "0"), levels = c("0", "1")),
    `Insuficiencia Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1"))
  )

# 3. Predicciones sobre TEST
predicciones_test <- predict(modelo_final, data_test, type = "prob") |> 
  bind_cols(data_test) |> 
  mutate(
    clase_ajustada = factor(ifelse(.pred_1 >= umbral_optimo, "1", "0"), levels = c("0", "1")),
    `Insuficiencia Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1"))
  )

# 4. Métricas categóricas (sin ROC)
metricas_clasicas <- metric_set(accuracy, sens, specificity, precision, f_meas, detection_prevalence, j_index)

metricas_train <- metricas_clasicas(predicciones_train, 
                                    truth = `Insuficiencia Renal`, 
                                    estimate = clase_ajustada, 
                                    event_level = "second")

metricas_test <- metricas_clasicas(predicciones_test, 
                                   truth = `Insuficiencia Renal`, 
                                   estimate = clase_ajustada, 
                                   event_level = "second")

# 5. AUC (ROC) por separado
roc_auc_train <- roc_auc(predicciones_train, 
                         truth = `Insuficiencia Renal`, 
                         .pred_1, 
                         event_level = "second")

roc_auc_test <- roc_auc(predicciones_test, 
                        truth = `Insuficiencia Renal`, 
                        .pred_1, 
                        event_level = "second")

# 6. Mostrar resultados
cat("MÉTRICAS EN TRAIN:\n")
print(bind_rows(metricas_train, roc_auc_train))

cat(" MÉTRICAS EN TEST:\n")
print(bind_rows(metricas_test, roc_auc_test))


#### CURVA LIFT MODELO LASSO ####---------------------------------------------------------------------------------------------------------------------------------------

library(dplyr)
library(ggplot2)

# Ordenar predicciones en test de mayor a menor probabilidad de clase positiva
pred_lift <- predicciones_test %>%
  arrange(desc(.pred_1)) %>%
  mutate(rank = row_number(),
         percentile = ntile(rank, 10))  # Dividir en 10 grupos (deciles)

# Obtener los pacientes por decil
pacientes_por_decil <- pred_lift %>%
  select(patient_id, .pred_1, percentile)  # Extraer patient_id y probabilidad predicha por decil

# Ver los pacientes en el primer decil
primer_decil_pacientes <- pacientes_por_decil %>%
  filter(percentile == 1)

# Ver los pacientes en el último decil
ultimo_decil_pacientes <- pacientes_por_decil %>%
  filter(percentile == 10)

# Mostrar los pacientes en el primer decil
print(primer_decil_pacientes)

# Mostrar los pacientes en el último decil
print(ultimo_decil_pacientes)

# Tasa positiva global (baseline)
baseline_rate <- mean(as.numeric(as.character(pred_lift$`Insuficiencia Renal`)))

# Calcular lift por decil
lift_df <- pred_lift %>%
  group_by(percentile) %>%
  summarise(
    n_obs = n(),
    positives = sum(as.numeric(as.character(`Insuficiencia Renal`))),
    positive_rate = positives / n_obs
  ) %>%
  mutate(lift = positive_rate / baseline_rate,
         percentile_label = percentile * 10)  # Para mostrar %

# Graficar curva Lift con punto del decil 10 destacado
ggplot(lift_df, aes(x = percentile_label, y = lift)) +
  geom_line() +
  geom_point() +
  geom_point(data = valor_decil_10, aes(x = percentile_label, y = lift), color = "blue", size = 3) +  # punto destacado
  geom_text(data = valor_decil_10, aes(x = percentile_label, y = lift, 
                                       label = paste0("Lift: ", round(lift, 2))),
            vjust = -1, color = "blue", size = 4) +  # etiqueta
  geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
  labs(
    title = "CURVA LIFT MODELO LASSO",
    x = "Percentil acumulado (%)",
    y = "Lift (Ratio tasa positiva / tasa base)"
  ) +
  theme_minimal()


# Tasa positiva global
baseline_rate <- mean(as.numeric(as.character(pred_lift$`Insuficiencia Renal`)))

# Ver los resultados por decil
print(lift_df)

# Ver directamente los datos del primer decil
primer_decil <- lift_df %>% filter(percentile == 1)

cat("Tasa global de insuficiencia renal:", round(baseline_rate * 100, 2), "%\n")
cat("Tasa en el primer decil:", round(primer_decil$positive_rate * 100, 2), "%\n")
cat("Lift en el primer decil:", round(primer_decil$lift, 2), "\n")



write.csv(pacientes_por_decil, "/Users/laurariera/Desktop/TFM/pacientes_por_decil.csv", row.names = FALSE)


## VIP MODELO LASSO ----------------------------------------------------------------------------------------------------------------------
library (vip)
p <- vip(modelo_final, num_features = 20)
p + 
  ggtitle("IMPORTANCIA VARIABLES MODELO FINAL") +
  ylab("Importancia") +
  xlab ("Variables") +
  theme_minimal() + 
  geom_col(fill = "#ADD8E6")


###OLD----------------------------------------
library(dplyr)
library(ggplot2)

# Ordenar predicciones en test de mayor a menor probabilidad de clase positiva
pred_lift <- predicciones_test %>%
  arrange(desc(.pred_1)) %>%
  mutate(rank = row_number(),
         percentile = ntile(rank, 10))  # Dividir en 10 grupos (deciles)

# Tasa positiva global (baseline)
baseline_rate <- mean(as.numeric(as.character(pred_lift$`Insuficiencia Renal`)))

# Calcular lift por decil
lift_df <- pred_lift %>%
  group_by(percentile) %>%
  summarise(
    n_obs = n(),
    positives = sum(as.numeric(as.character(`Insuficiencia Renal`))),
    positive_rate = positives / n_obs
  ) %>%
  mutate(lift = positive_rate / baseline_rate,
         percentile_label = percentile * 10)  # Para mostrar %


# Obtener el valor del decil 10
valor_decil_10 <- lift_df %>% filter(percentile == 1)

# Graficar curva Lift con punto del decil 10 destacado
ggplot(lift_df, aes(x = percentile_label, y = lift)) +
  geom_line() +
  geom_point() +
  geom_point(data = valor_decil_10, aes(x = percentile_label, y = lift), color = "blue", size = 3) +  # punto destacado
  geom_text(data = valor_decil_10, aes(x = percentile_label, y = lift, 
                                       label = paste0("Lift: ", round(lift, 2))),
            vjust = -1, color = "blue", size = 4) +  # etiqueta
  geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
  labs(
    title = "CURVA LIFT MODELO LASSO",
    x = "Percentil acumulado (%)",
    y = "Lift (Ratio tasa positiva / tasa base)"
  ) +
  theme_minimal()


# Tasa positiva global
baseline_rate <- mean(as.numeric(as.character(pred_lift$`Insuficiencia Renal`)))

# Ver los resultados por decil
print(lift_df)

# Ver directamente los datos del primer decil
primer_decil <- lift_df %>% filter(percentile == 1)

cat("Tasa global de insuficiencia renal:", round(baseline_rate * 100, 2), "%\n")
cat("Tasa en el primer decil:", round(primer_decil$positive_rate * 100, 2), "%\n")
cat("Lift en el primer decil:", round(primer_decil$lift, 2), "\n")




#------------ELASTIC NET----------------------------------------------------------------------------------------------------------------------
#empleamos misma semilla y receta que en lasso
logistic_enet_model_tune <- logistic_reg(penalty = tune(), mixture = tune()) |>
  set_engine("glmnet") |>  # Usar glmnet para soporte de regularización
  set_mode("classification")  # Configurar modo clasificación

# Configurar el flujo de trabajo
wflow_enet_tune <- workflow() |>
  add_model(logistic_enet_model_tune) |>
  add_recipe(rec_reg_tune)

# Crear un grid para tunear penalty y mixture
grid_enet_tune <- grid_regular(
  penalty(range = c(-5, 0)),  # Lambda en escala log
  mixture(range = c(0, 1)),  # Combinación de L1 y L2
  levels = 10                # Número de combinaciones por parámetro
)


wflow_enet_tune

## ---------------------------------------------------------------------------------------------------------------------------------------
#Fijamos misma semilla que en la validación cruzada de lasso
library(parallel)
library(doParallel)
set.seed(101112) # Semilla para validación cruzada
k1 <- 5; k2 <- 10
data_cvrep <- rsample::vfold_cv(data_train, v = k1, repeats = k2)
metricas <- metric_set(accuracy, sens, spec, precision, f_meas, detection_prevalence, roc_auc, j_index)

#Validación cruzada con los distintos workflows para estimar los mejores hiperparametros:
ctrl <- control_resamples(event_level = "second") 
cl <- makePSOCKcluster(4)
registerDoParallel(cl)

enet_reg_tune <- tune_grid(wflow_enet_tune,
                           resamples = data_cvrep,
                           grid = grid_enet_tune,
                           metrics = metricas,
                           control=ctrl)


stopCluster(cl)

## ----warning=FALSE----------------------------------------------------------------------------------------------------------------------
#Selección del hiperparámetro con mejor F1 score
##ELASTIC-NET--------------------------------------------------------------
# Mostrar y seleccionar el mejor modelo
enet_reg_tune |>
  show_best(metric = "f_meas")
best_enet_reg_tune <- enet_reg_tune |>
  select_best(metric = "f_meas")

# Filtrar las métricas correspondientes al mejor modelo
enet_metrics_best <- enet_reg_tune |>
  collect_metrics() |>  # Recopilar todas las métricas
  filter(penalty == best_enet_reg_tune$penalty & mixture == best_enet_reg_tune$mixture)

# Mostrar las métricas
print(enet_metrics_best)

# Finalizar el workflow con los mejores hiperparámetros
finalwf_enet <- wflow_enet_tune |>
  finalize_workflow(best_enet_reg_tune)
#finalwf_enet

## ----warning=FALSE----------------------------------------------------------------------------------------------------------------------
# Crear nuevo esquema de validación cruzada
set.seed(202201)
data_cvrep_new <- rsample::vfold_cv(data_train, v = 5, repeats = 10)
ctrl <- control_grid(event_level = "second") 
cl <- makePSOCKcluster(4)
registerDoParallel(cl)

# Evaluar el modelo final con la nueva validación cruzada
final_elastic_cv <- fit_resamples(
  finalwf_enet,
  resamples = data_cvrep_new,
  metrics = metricas,
  control = ctrl
)

# Recopilar métricas
metrics_final_elastic <- collect_metrics(final_elastic_cv)

stopCluster(cl)
print(metrics_final_elastic)


## VIP MODELO LASSO ----------------------------------------------------------------------------------------------------------------------
library (vip)
p <- vip(modelo_final, num_features = 20)
p + 
  ggtitle("IMPORTANCIA VARIABLES MODELO FINAL") +
  ylab("Importancia") +
  xlab ("Variables") +
  theme_minimal() + 
  geom_col(fill = "#ADD8E6")




#RANDOM FOREST - MODELO PREDICTIVO II TÉSIS FINAL

## ----setup, include=FALSE---------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(warning = FALSE)
options(warn = -1)  # Desactiva las advertencias

## ---------------------------------------------------------------------------------------------------------------------------------------
library(themis)
suppressPackageStartupMessages(library("tidymodels"))
tidymodels_prefer()

## ---------------------------------------------------------------------------------------------------------------------------------------
library(readxl)
dataset <- read_excel("/Users/rociojimenezcatalan/Desktop/MASTER EAE/TFM/dataset_features.xlsx")

## ---------------------------------------------------------------------------------------------------------------------------------------
#TRANSFORMACIÓN VARIABLES DATASET COMPLETO
### 2.1-Variables binarias ----------------------------------------------------------------
# Lista de variables a convertir en binarias
dataset <- dataset |>
  mutate(toma_iron_supplements = as.factor(ifelse(toma_iron_supplements == 1, 1, 0))) # 1 si toma suplementos iron, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_cardiovascular = as.factor(ifelse(toma_cardiovascular == 1, 1, 0))) # 1 si toma cardiovascular, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_renal = as.factor(ifelse(toma_renal == 1, 1, 0))) # 1 si toma renal, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_corticosteroid = as.factor(ifelse(toma_corticosteroid == 1, 1, 0))) # 1 si toma corticosteroides, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_diuretic = as.factor(ifelse(toma_diuretic == 1, 1, 0))) # 1 si toma diurético, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_vasodilator = as.factor(ifelse(toma_vasodilator == 1, 1, 0))) # 1 si toma vasodilatador, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_vasopressor = as.factor(ifelse(toma_vasopressor == 1,1, 0))) # 1 si toma vasopresor, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_anesthetic = as.factor(ifelse(toma_anesthetic == 1, 1, 0))) # 1 si toma anestésico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_supplement = as.factor(ifelse(toma_supplement == 1, 1, 0))) # 1 si toma suplemento, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_antipsychotic = as.factor(ifelse(toma_antipsychotic == 1, 1, 0))) # 1 si toma antipsicótico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_proton_pump_inhibitor = as.factor(ifelse(toma_proton_pump_inhibitor == 1, 1, 0))) # 1 si toma inhibidor de bomba de protones, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_urological = as.factor(ifelse(toma_urological == 1, 1, 0))) # 1 si toma medicamento urológico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_immunosuppressant = as.factor(ifelse(toma_immunosuppressant == 1, 1, 0))) # 1 si toma inmunosupresor, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_sedative = as.factor(ifelse(toma_sedative == 1, 1, 0))) # 1 si toma sedante, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_antihistamine = as.factor(ifelse(toma_antihistamine == 1,1, 0))) # 1 si toma antihistamínico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_h2_antihistamine = as.factor(ifelse(toma_h2_antihistamine ==  1,1, 0))) # 1 si toma antihistamínico H2, 0 en caso contrario
dataset <- dataset |>
  mutate(Antagonist = as.factor(ifelse(Antagonist == 1, 1, 0))) # 1 si toma antagonista, 0 en caso contrario
dataset <- dataset |>
  mutate(Antiflatulent = as.factor(ifelse(Antiflatulent == 1, 1, 0))) # 1 si toma antiflatulento, 0 en caso contrario
dataset <- dataset |>
  mutate(Antiseptic = as.factor(ifelse(Antiseptic == 1, 1, 0))) # 1 si toma antiséptico, 0 en caso contrario
dataset <- dataset |>
  mutate(Antitussive = as.factor(ifelse(Antitussive == 1, 1, 0))) # 1 si toma antitusígeno, 0 en caso contrario
dataset <- dataset |>
  mutate(Laxative = as.factor(ifelse(Laxative == 1, 1, 0))) # 1 si toma laxante, 0 en caso contrario
dataset <- dataset |>
  mutate(`Opioid Agonist-Antagonist` = as.factor(ifelse(`Opioid Agonist-Antagonist` == 1, 1, 0))) # 1 si toma agonista-antagonista opioide, 0 en caso contrario
dataset <- dataset |>
  mutate(Radiology = as.factor(ifelse(Radiology == 1, 1, 0))) # 1 si toma radiología, 0 en caso contrario
dataset <- dataset |>
  mutate(Respiratory = as.factor(ifelse(Respiratory == 1, 1, 0))) # 1 si toma respiratorio, 0 en caso contrario
dataset <- dataset |>
  mutate(`Smoking cessation` = as.factor(ifelse(`Smoking cessation` == 1, 1, 0))) # 1 si toma para dejar de fumar, 0 en caso contrario
dataset <- dataset |>
  mutate(Vaccine = as.factor(ifelse(Vaccine == 1, 1, 0))) # 1 si toma vacuna, 0 en caso contrario
dataset <- dataset |>
  mutate(Cardiología = as.factor(ifelse(Cardiología == 1, 1, 0))) # 1 si toma medicamentos de cardiología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Cirugía / Procedimientos Médicos` = as.factor(ifelse(`Cirugía / Procedimientos Médicos` == 1, 1, 0))) # 1 si toma medicamentos para cirugía, 0 en caso contrario
dataset <- dataset |>
  mutate(`Enfermedades Infecciosas` = as.factor(ifelse(`Enfermedades Infecciosas` == 1, 1, 0))) # 1 si toma medicamentos para enfermedades infecciosas, 0 en caso contrario
dataset <- dataset |>
  mutate(`Factores Sociales / Exposición / Historial` = as.factor(ifelse(`Factores Sociales / Exposición / Historial` == 1, 1, 0))) # 1 si tiene factores sociales/exposición/historial relevante, 0 en caso contrario
dataset <- dataset |>
  mutate(`Gastroenterología / Digestivo` = as.factor(ifelse(`Gastroenterología / Digestivo` == 1, 1, 0))) # 1 si toma medicamentos de gastroenterología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Metabólicas Y Nutricionales` = as.factor(ifelse(`Metabólicas Y Nutricionales` == 1, 1, 0))) # 1 si toma medicamentos metabólicos o nutricionales, 0 en caso contrario
dataset <- dataset |>
  mutate(Nefrología = as.factor(ifelse(Nefrología == 1, 1, 0))) # 1 si toma medicamentos de nefrología, 0 en caso contrario
dataset <- dataset |>
  mutate(Neumología = as.factor(ifelse(Neumología == 1, 1, 0))) # 1 si toma medicamentos de neumología, 0 en caso contrario
dataset <- dataset |>
  mutate(Oncología = as.factor(ifelse(Oncología == 1, 1, 0))) # 1 si toma medicamentos oncológicos, 0 en caso contrario
dataset <- dataset |>
  mutate(Reumatología = as.factor(ifelse(Reumatología == 1, 1, 0))) # 1 si toma medicamentos de reumatología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Salud Mental Y Neurológica` = as.factor(ifelse(`Salud Mental Y Neurológica` == 1, 1, 0))) # 1 si toma medicamentos para salud mental/neurología, 0 en caso contrario
dataset <- dataset |>
  mutate(murio = as.factor(ifelse(murio == 1, 1, 0))) # 1 si la persona ha muerto, 0 en caso contrario
dataset <- dataset |>
  mutate(gender = as.factor(ifelse(gender == "F", 1, 0))) # 1 si la persona es mujer, 0 si es hombre


### 2.2-Variables ordinales --------------------------------------------------------------------------------------------------------------------------
# Variables categóricas ordinales (con orden)

dataset <- dataset |>
  mutate(Analgesic_class = factor(Analgesic_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antibiotic_class = factor(Antibiotic_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Anticoagulant_class = factor(Anticoagulant_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antidepressant_class = factor(Antidepressant_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antihypertensive_class = factor(Antihypertensive_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antiplatelet_class = factor(Antiplatelet_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Electrolyte_class = factor(Electrolyte_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Fluid & Electrolyte_class` = factor(`Fluid & Electrolyte_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Lipid-lowering_class` = factor(`Lipid-lowering_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Endocrine & Metabolic_class` = factor(`Endocrine & Metabolic_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 


### Variable target binaria------------------------------------------------------------------------------------------------------------------------------------------------------------------------
dataset <- dataset |>
  mutate(`Insuficiencia Renal` = as.factor(ifelse(`Insuficiencia Renal` == 1, 1, 0)))

### Descripciones estadísticas-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
head (dataset)
str (dataset)
summary (dataset)
colnames(dataset)

### lo de la edad-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
dataset <- dataset %>%
  mutate(anchor_age = as.numeric(anchor_age))  # Convertir a numérico si no lo es ya

dataset <- dataset %>%
  mutate(anchor_age = case_when(
    anchor_age >= 18 & anchor_age < 25 ~ "[18-25)", 
    anchor_age >= 25 & anchor_age < 35 ~ "[25-35)", 
    anchor_age >= 35 & anchor_age < 45 ~ "[35-45)", 
    anchor_age >= 45 & anchor_age < 55 ~ "[45-55)", 
    anchor_age >= 55 & anchor_age < 65 ~ "[55-65)", 
    anchor_age >= 65 & anchor_age <= 75 ~ "[65-75]", 
    TRUE ~ NA_character_  # Si hay valores fuera de estos rangos, los marcamos como NA
  ))
# Verificar los resultados después de la conversión
table(dataset$anchor_age)

# Convertir a factor con los niveles correctos
dataset <- dataset %>%
  mutate(anchor_age = factor(anchor_age, levels = c("[18-25)", "[25-35)", "[35-45)", "[45-55)", 
                                                    "[55-65)", "[65-75]"), ordered = TRUE))



### RANDOM FOREST --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#1. FIJAMOS SEMILLA---------------------------------------------------------------------
suppressPackageStartupMessages(library("tidymodels"))
set.seed(123)  # Semilla para dividir en training y test
data_split <- rsample::initial_split(dataset, prop = 0.7)
data_train <- rsample::training(data_split)
data_test <- rsample::testing(data_split)

#2.RECETA ---------------------------------------------------------------------
rec_reg_tune <- recipe(`Insuficiencia Renal`~ ., data = data_train) |> 
  update_role(patient_id, new_role = "none") |> 
  step_nzv(all_predictors()) 

## RANDOM FOREST CON TUNEADO---------------------------------------------------------------------
rf_model_tune <- rand_forest(mtry = tune(), trees = tune(), 
                             min_n = tune()) |> 
  set_engine("randomForest") |>  #ranger en vez de randomForest si tengo muchas categorias
  set_mode("classification")
wflow_rf_tune <-  workflow() |>
  add_model(rf_model_tune) |>
  add_recipe(rec_reg_tune)

#Establecer el grid de posibles valores de los hiperparámetros a tunear
wflow_rf_tune_param  <- extract_parameter_set_dials(wflow_rf_tune)
wflow_rf_tune_param  <- extract_parameter_set_dials(wflow_rf_tune)
grid_rf_tune <- grid_regular(
  mtry(range = c(3L, 25L)),         # menos variables por nodo
  trees(range = c(300L, 1000L)),    # menos árboles
  min_n(range = c(20L, 50L)),       # nodos más grandes = menos profundidad
  levels = 5
)
grid_rf_tune

------------------------------------------------------------------------------------------------------------------------------------------
  library(parallel)
library(doParallel)
set.seed(101112)
k1 <- 5; k2 <- 1
data_cvrep <- rsample::vfold_cv(data_train, v = k1, repeats = k2)
ctrl <- control_grid(event_level = "second") 
metricas <- metric_set(accuracy, sens, precision, f_meas, spec,
                       roc_auc, detection_prevalence, j_index)
cl <- makePSOCKcluster(4)
registerDoParallel(cl)
rf_reg_tune <- tune_grid(wflow_rf_tune,
                         data_cvrep,
                         grid = grid_rf_tune,
                         metrics = metricas,
                         control=ctrl)
stopCluster(cl)
rf_reg_tune |>
  collect_metrics()

## ---------------------------------------------------------------------
# Mostrar y seleccionar el mejor modelo
rf_reg_tune |>
  show_best(metric = "roc_auc")
best_rf_reg_tune <- rf_reg_tune |>
  select_best(metric = "roc_auc")

# Filtrar las métricas correspondientes a los mejores hiperparámetros
rf_metrics_best <- rf_reg_tune |>
  collect_metrics() |> 
  filter(mtry == best_rf_reg_tune$mtry)|>
  filter(trees==best_rf_reg_tune$trees) |>
  filter(min_n==best_rf_reg_tune$min_n)

# Mostrar las métricas
print(rf_metrics_best)

finalwf_rf <- wflow_rf_tune |>
  finalize_workflow(best_rf_reg_tune)
finalwf_rf

## VALIDACIÓN CRUZADA ---------------------------------------------------------------------
set.seed(202201)
k1 <- 5; k2 <- 1
data_cvrep2 <- rsample::vfold_cv(data_train, v = k1, repeats = k2)
cl <- makePSOCKcluster(4)
registerDoParallel(cl)
asses_finalwf_rf <-
  fit_resamples(finalwf_rf,
                resamples = data_cvrep2,
                metrics = metricas,
                control=ctrl)
stopCluster(cl)
collect_metrics(asses_finalwf_rf)


## ENTRENAMIENTO FINAL ---------------------------------------------------------------------

umbral_optimo <- 0.2434532
ctrl = control_last_fit(event_level = "second")

rf_final <- last_fit(finalwf_rf, split = data_split, metrics = metricas, control = ctrl)
collect_metrics(rf_final)



#obetenr predicciones con probabilidad
final_preds <- collect_predictions(rf_final)
final_preds<-final_preds  |>
  mutate(.pred_class_custom=if_else(.pred_1 >=umbral_optimo, "1", "0")|> factor (levels=c("0", "1")))

#evaluar con el nuevo umbral

metrics(final_preds, truth=`Insuficiencia Renal`, estimate=.pred_class_custom, options=metricas)

#Matriz de confusion

conf_mat(final_preds, truth=`Insuficiencia Renal`, estimate=.pred_class_custom)



#### CURVA LIFT ####-----------------------------------------
library(dplyr)
library(ggplot2)

# Ordenar predicciones por probabilidad descendente
pred_lift <- predicciones_test %>%
  arrange(desc(.pred_1)) %>%
  mutate(rank = row_number(),
         percentile = ntile(rank, 10))  # Dividir en 10 deciles

# Calcular tasa global de positivos (baseline)
baseline_rate <- mean(as.numeric(as.character(pred_lift$`Insuficiencia Renal`)))

# Calcular lift por decil
lift_df <- pred_lift %>%
  group_by(percentile) %>%
  summarise(
    n_obs = n(),
    positives = sum(as.numeric(as.character(`Insuficiencia Renal`))),
    positive_rate = positives / n_obs
  ) %>%
  mutate(
    lift = positive_rate / baseline_rate,
    percentile_label = percentile * 10
  )

# Graficar curva Lift
ggplot(lift_df, aes(x = percentile_label, y = lift)) +
  geom_line() +
  geom_point() +
  geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
  labs(
    title = "CURVA LIFT RANDOM FOREST",
    x = "Percentil acumulado (%)",
    y = "Lift (Ratio tasa positiva / tasa base)"
  ) +
  theme_minimal()



## --------------------------------------------------------------------------------
##- MODELO PREDICTIVO I TÉSIS FINAL-SVM LINEAL Y RADIAL

## ----setup, include=FALSE---------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(warning = FALSE)
options(warn = -1)  # Desactiva las advertencias

## ---------------------------------------------------------------------------------------------------------------------------------------
library(themis)
suppressPackageStartupMessages(library("tidymodels"))
tidymodels_prefer()

## ---------------------------------------------------------------------------------------------------------------------------------------
library(readxl)
dataset <- read_excel("/Users/rociojimenezcatalan/Desktop/MASTER EAE/TFM/dataset_features.xlsx")

## ---------------------------------------------------------------------------------------------------------------------------------------
#TRANSFORMACIÓN VARIABLES DATASET COMPLETO
### 2.1-Variables binarias ----------------------------------------------------------------
# Lista de variables a convertir en binarias
dataset <- dataset |>
  mutate(toma_iron_supplements = as.factor(ifelse(toma_iron_supplements == 1, 1, 0))) # 1 si toma suplementos iron, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_cardiovascular = as.factor(ifelse(toma_cardiovascular == 1, 1, 0))) # 1 si toma cardiovascular, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_renal = as.factor(ifelse(toma_renal == 1, 1, 0))) # 1 si toma renal, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_corticosteroid = as.factor(ifelse(toma_corticosteroid == 1, 1, 0))) # 1 si toma corticosteroides, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_diuretic = as.factor(ifelse(toma_diuretic == 1, 1, 0))) # 1 si toma diurético, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_vasodilator = as.factor(ifelse(toma_vasodilator == 1, 1, 0))) # 1 si toma vasodilatador, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_vasopressor = as.factor(ifelse(toma_vasopressor == 1,1, 0))) # 1 si toma vasopresor, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_anesthetic = as.factor(ifelse(toma_anesthetic == 1, 1, 0))) # 1 si toma anestésico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_supplement = as.factor(ifelse(toma_supplement == 1, 1, 0))) # 1 si toma suplemento, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_antipsychotic = as.factor(ifelse(toma_antipsychotic == 1, 1, 0))) # 1 si toma antipsicótico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_proton_pump_inhibitor = as.factor(ifelse(toma_proton_pump_inhibitor == 1, 1, 0))) # 1 si toma inhibidor de bomba de protones, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_urological = as.factor(ifelse(toma_urological == 1, 1, 0))) # 1 si toma medicamento urológico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_immunosuppressant = as.factor(ifelse(toma_immunosuppressant == 1, 1, 0))) # 1 si toma inmunosupresor, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_sedative = as.factor(ifelse(toma_sedative == 1, 1, 0))) # 1 si toma sedante, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_antihistamine = as.factor(ifelse(toma_antihistamine == 1,1, 0))) # 1 si toma antihistamínico, 0 en caso contrario
dataset <- dataset |>
  mutate(toma_h2_antihistamine = as.factor(ifelse(toma_h2_antihistamine ==  1,1, 0))) # 1 si toma antihistamínico H2, 0 en caso contrario
dataset <- dataset |>
  mutate(Antagonist = as.factor(ifelse(Antagonist == 1, 1, 0))) # 1 si toma antagonista, 0 en caso contrario
dataset <- dataset |>
  mutate(Antiflatulent = as.factor(ifelse(Antiflatulent == 1, 1, 0))) # 1 si toma antiflatulento, 0 en caso contrario
dataset <- dataset |>
  mutate(Antiseptic = as.factor(ifelse(Antiseptic == 1, 1, 0))) # 1 si toma antiséptico, 0 en caso contrario
dataset <- dataset |>
  mutate(Antitussive = as.factor(ifelse(Antitussive == 1, 1, 0))) # 1 si toma antitusígeno, 0 en caso contrario
dataset <- dataset |>
  mutate(Laxative = as.factor(ifelse(Laxative == 1, 1, 0))) # 1 si toma laxante, 0 en caso contrario
dataset <- dataset |>
  mutate(`Opioid Agonist-Antagonist` = as.factor(ifelse(`Opioid Agonist-Antagonist` == 1, 1, 0))) # 1 si toma agonista-antagonista opioide, 0 en caso contrario
dataset <- dataset |>
  mutate(Radiology = as.factor(ifelse(Radiology == 1, 1, 0))) # 1 si toma radiología, 0 en caso contrario
dataset <- dataset |>
  mutate(Respiratory = as.factor(ifelse(Respiratory == 1, 1, 0))) # 1 si toma respiratorio, 0 en caso contrario
dataset <- dataset |>
  mutate(`Smoking cessation` = as.factor(ifelse(`Smoking cessation` == 1, 1, 0))) # 1 si toma para dejar de fumar, 0 en caso contrario
dataset <- dataset |>
  mutate(Vaccine = as.factor(ifelse(Vaccine == 1, 1, 0))) # 1 si toma vacuna, 0 en caso contrario
dataset <- dataset |>
  mutate(Cardiología = as.factor(ifelse(Cardiología == 1, 1, 0))) # 1 si toma medicamentos de cardiología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Cirugía / Procedimientos Médicos` = as.factor(ifelse(`Cirugía / Procedimientos Médicos` == 1, 1, 0))) # 1 si toma medicamentos para cirugía, 0 en caso contrario
dataset <- dataset |>
  mutate(`Enfermedades Infecciosas` = as.factor(ifelse(`Enfermedades Infecciosas` == 1, 1, 0))) # 1 si toma medicamentos para enfermedades infecciosas, 0 en caso contrario
dataset <- dataset |>
  mutate(`Factores Sociales / Exposición / Historial` = as.factor(ifelse(`Factores Sociales / Exposición / Historial` == 1, 1, 0))) # 1 si tiene factores sociales/exposición/historial relevante, 0 en caso contrario
dataset <- dataset |>
  mutate(`Gastroenterología / Digestivo` = as.factor(ifelse(`Gastroenterología / Digestivo` == 1, 1, 0))) # 1 si toma medicamentos de gastroenterología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Metabólicas Y Nutricionales` = as.factor(ifelse(`Metabólicas Y Nutricionales` == 1, 1, 0))) # 1 si toma medicamentos metabólicos o nutricionales, 0 en caso contrario
dataset <- dataset |>
  mutate(Nefrología = as.factor(ifelse(Nefrología == 1, 1, 0))) # 1 si toma medicamentos de nefrología, 0 en caso contrario
dataset <- dataset |>
  mutate(Neumología = as.factor(ifelse(Neumología == 1, 1, 0))) # 1 si toma medicamentos de neumología, 0 en caso contrario
dataset <- dataset |>
  mutate(Oncología = as.factor(ifelse(Oncología == 1, 1, 0))) # 1 si toma medicamentos oncológicos, 0 en caso contrario
dataset <- dataset |>
  mutate(Reumatología = as.factor(ifelse(Reumatología == 1, 1, 0))) # 1 si toma medicamentos de reumatología, 0 en caso contrario
dataset <- dataset |>
  mutate(`Salud Mental Y Neurológica` = as.factor(ifelse(`Salud Mental Y Neurológica` == 1, 1, 0))) # 1 si toma medicamentos para salud mental/neurología, 0 en caso contrario
dataset <- dataset |>
  mutate(murio = as.factor(ifelse(murio == 1, 1, 0))) # 1 si la persona ha muerto, 0 en caso contrario
dataset <- dataset |>
  mutate(gender = as.factor(ifelse(gender == "F", 1, 0))) # 1 si la persona es mujer, 0 si es hombre

### 2.2-Variables ordinales --------------------------------------------------------------------------------------------------------------------------
# Variables categóricas ordinales (con orden)
# Asegúrate de que anchor_age sea numérico
dataset <- dataset %>%
  mutate(anchor_age = as.numeric(anchor_age))  # Convertir a numérico si no lo es ya

dataset <- dataset %>%
  mutate(anchor_age = case_when(
    anchor_age >= 18 & anchor_age < 25 ~ "[18-25)", 
    anchor_age >= 25 & anchor_age < 35 ~ "[25-35)", 
    anchor_age >= 35 & anchor_age < 45 ~ "[35-45)", 
    anchor_age >= 45 & anchor_age < 55 ~ "[45-55)", 
    anchor_age >= 55 & anchor_age < 65 ~ "[55-65)", 
    anchor_age >= 65 & anchor_age <= 75 ~ "[65-75]", 
    TRUE ~ NA_character_  # Si hay valores fuera de estos rangos, los marcamos como NA
  ))
# Verificar los resultados después de la conversión
table(dataset$anchor_age)

# Convertir a factor con los niveles correctos
dataset <- dataset %>%
  mutate(anchor_age = factor(anchor_age, levels = c("[18-25)", "[25-35)", "[35-45)", "[45-55)", 
                                                    "[55-65)", "[65-75]"), ordered = TRUE))

# Verificar los resultados después de la conversión
table(dataset$anchor_age)

dataset <- dataset |>
  mutate(Analgesic_class = factor(Analgesic_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antibiotic_class = factor(Antibiotic_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Anticoagulant_class = factor(Anticoagulant_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antidepressant_class = factor(Antidepressant_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antihypertensive_class = factor(Antihypertensive_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Antiplatelet_class = factor(Antiplatelet_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(Electrolyte_class = factor(Electrolyte_class, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Fluid & Electrolyte_class` = factor(`Fluid & Electrolyte_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Lipid-lowering_class` = factor(`Lipid-lowering_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 
dataset <- dataset |>
  mutate(`Endocrine & Metabolic_class` = factor(`Endocrine & Metabolic_class`, ordered = TRUE, levels = c(0, 1, 2, 3))) 


### Variable target binaria------------------------------------------------------------------------------------------------------------------------------------------------------------------------
dataset <- dataset |>
  mutate(`Insuficiencia Renal` = as.factor(ifelse(`Insuficiencia Renal` == 1, 1, 0)))

### Descripciones estadísticas-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
head (dataset)
str (dataset)
summary (dataset)
colnames(dataset)
na_rows <- dataset %>%
  filter(is.na(anchor_age)) %>%
  select(patient_id, anchor_age)  # Seleccionamos los patient_id y la columna anchor_age

# Ver las filas con NA en anchor_age
print(na_rows)

#1-Fijar semilla y splitting-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
suppressPackageStartupMessages(library("tidymodels"))
set.seed(123)  # Semilla para dividir en training y test
data_split <- rsample::initial_split(dataset, prop = 0.7)
data_train <- rsample::training(data_split)
data_test <- rsample::testing(data_split)


## Receta------------------------------------------------------------------------
rec_svm <- recipe(`Insuficiencia Renal`~ ., data = data_train) |>
  update_role(patient_id, new_role = "none") |>
  step_nzv(all_predictors()) |>
  step_YeoJohnson(all_numeric_predictors()) |>
  step_integer(all_ordered_predictors()) |> 
  step_nzv(all_predictors()) |>
  step_normalize(all_numeric_predictors())|>
  step_zv(all_predictors())

rec_prep <- prep(rec_svm)
df_rec <- juice(rec_prep)
glimpse(df_rec)

## Modelo SVM lineal------------------------------------------------------------------------
svmlin_model <- svm_linear(cost = tune()) |> 
  set_engine("kernlab")  |>
  set_mode("classification")
svmlin_wf <- workflow() |> add_recipe(rec_svm) |> 
  add_model(svmlin_model)


# Tuning grid
param_tuning_svm <- svmlin_wf  |>
  extract_parameter_set_dials()


grid_svm_tune <- tibble(cost = 10^seq(0.8, 2, length.out = 7))

grid_svm_tune$cost

## ------------------------------------------------------------------------

# Validación cruzada
set.seed(101112) # Semilla para validación cruzada
k1 <- 5; k2 <- 10
metricas <- metric_set(accuracy, sens, spec, precision, f_meas, detection_prevalence, roc_auc, j_index)
svm_cvrep_tune <- rsample::vfold_cv(data_train, v = k1, repeats = k2, strata = `Insuficiencia Renal`) #Esto estratifica los folds, asegurando que todos tengan representación de cada clase.

ctrl <- control_resamples(event_level = "second")

# Paralelización y tuning
library(parallel)
library(doParallel)

cl <- makePSOCKcluster(8)
registerDoParallel(cl)
svm_lin_reg_tune <- tune_grid(svmlin_wf,
                              svm_cvrep_tune,
                              grid = grid_svm_tune,
                              metrics = metricas, 
                              control = ctrl)
stopCluster(cl)

# Resultados
svm_lin_reg_tune |>
  collect_metrics()


#Selección del hiperparámetro con mejor ROC score

# Mostrar y seleccionar el mejor modelo
svm_lin_reg_tune |>
  show_best(metric = "roc_auc")
best_svm_lin_reg_tune<- svm_lin_reg_tune|>
  select_best(metric = "roc_auc")

# Filtrar las métricas correspondientes al mejor modelo
svm_lin_metrics_best <- svm_lin_reg_tune |>
  collect_metrics() |>  # Recopilar todas las métricas
  filter(cost == best_svm_lin_reg_tune$cost)

# Mostrar las métricas
print(svm_lin_metrics_best)

# Finalizar el workflow con los mejores hiperparámetros
finalwf_svm <- svmlin_wf |>
  finalize_workflow(best_svm_lin_reg_tune)


# Crear nuevo esquema de validación cruzada
set.seed(202201)
data_cvrep_new <- rsample::vfold_cv(data_train, v = 5, repeats = 10)
ctrl <- control_grid(event_level = "second", save_pred = TRUE) 
cl <- makePSOCKcluster(4)
registerDoParallel(cl)

# Evaluar el modelo final con la nueva validación cruzada
final_svmmlin_cv <- fit_resamples(
  finalwf_svm ,
  resamples = data_cvrep_new,
  metrics = metricas,
  control = ctrl
)

# Recopilar métricas
metrics_final_svmlin <- collect_metrics(final_svmmlin_cv)

stopCluster(cl)
print(metrics_final_svmlin)

## ENTRENAMIENTO FINAL CON AJUSTE DE UMBRAL--------------------------------------------------------------------------------------------------------------------------
##INTENTO 2194823
final_model <- fit(finalwf_svm, data_train)
prob_preds <- predict(final_model, data_test, type = "prob") |>
  bind_cols(predict(final_model, data_test)) |>
  bind_cols(data_test %>% select(patient_id, Insuficiencia_Renal_Real = `Insuficiencia Renal`))

# Aplicar umbral y crear predicción binaria
umbral <- 0.2434532
prob_preds <- prob_preds %>%
  mutate(.pred_class_custom = if_else(.pred_1 >= umbral, "1", "0") %>%
           factor(levels = c("0", "1")))

head(prob_preds)

library(yardstick)
library(dplyr)

# Asegúrate de que las variables estén en el formato correcto
prob_preds <- prob_preds %>%
  mutate(
    Insuficiencia_Renal_Real = factor(Insuficiencia_Renal_Real, levels = c("0", "1")),
    .pred_class_custom = factor(.pred_class_custom, levels = c("0", "1"))
  )

# Crear tabla con truth, predicción binaria y probabilidad para métricas
metrics_data <- prob_preds %>%
  select(Insuficiencia_Renal_Real, .pred_class_custom, .pred_1)

# Definir métricas a calcular
metricas_clasicas <- metric_set(accuracy, sens, specificity, precision, f_meas, detection_prevalence, j_index)

# Calcular métricas categóricas usando la predicción ajustada por umbral
metricas_test <- metricas_clasicas(metrics_data,
                                   truth = Insuficiencia_Renal_Real,
                                   estimate = .pred_class_custom,
                                   event_level = "second")

# Calcular AUC con probabilidades continuas
roc_auc_test <- roc_auc(metrics_data,
                        truth = Insuficiencia_Renal_Real,
                        .pred_1,
                        event_level = "second")

# Combinar y mostrar resultados
resultados <- bind_rows(metricas_test, roc_auc_test)
print(resultados)

# --- Extraer y procesar predicciones de validación cruzada (CV) ---
cv_preds <- collect_predictions(final_svmmlin_cv) %>%
  mutate(
    .pred_class_custom = if_else(.pred_1 >= umbral, "1", "0") %>%
      factor(levels = c("0", "1")),
    `Insuficiencia Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1"))
  )

# --- Calcular métricas clásicas en CV ---
metricas_cv <- metricas_clasicas(cv_preds,
                                 truth = `Insuficiencia Renal`,
                                 estimate = .pred_class_custom,
                                 event_level = "second")

# --- Calcular AUC en CV ---
roc_auc_cv <- roc_auc(cv_preds,
                      truth = `Insuficiencia Renal`,
                      .pred_1,
                      event_level = "second")

# --- Mostrar métricas CV ---
resultados_cv <- bind_rows(metricas_cv, roc_auc_cv)
cat("Métricas en Validación Cruzada:\n")
print(resultados_cv)





#### CURVA LIFT CON SVM LINEAL ####----------------------------------------------------------------------------------------------------------

# Cargar librerías necesarias
library(dplyr)
library(ggplot2)

# Ordenar por probabilidad descendente (mayor riesgo a menor)
lift_data <- prob_preds %>%
  arrange(desc(.pred_1)) %>%
  mutate(rank = row_number(),
         percentile = ntile(rank, 10))  # Dividir en 10 deciles

# Calcular tasa global positiva (base rate)
base_rate <- mean(as.numeric(as.character(lift_data$Insuficiencia_Renal_Real)))

# Calcular lift por decil
lift_summary <- lift_data %>%
  group_by(percentile) %>%
  summarise(
    n = n(),
    positives = sum(as.numeric(as.character(Insuficiencia_Renal_Real))),
    positive_rate = positives / n
  ) %>%
  mutate(lift = positive_rate / base_rate,
         percentile_label = percentile * 10)

# Graficar curva lift
ggplot(lift_summary, aes(x = percentile_label, y = lift)) +
  geom_line() +
  geom_point() +
  geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
  labs(
    title = "Curva Lift - SVM Lineal",
    x = "Percentil acumulado (%)",
    y = "Lift (Tasa positiva / Tasa base)"
  ) +
  theme_minimal()






#--------------------- SVM RADIAL ---------------------------------------------------------------
svmrb_model_tune <- svm_rbf(cost = tune(), rbf_sigma = tune()) |> 
  set_engine("kernlab")  |>
  set_mode("classification")
svmrb_wf_tune <- workflow() |> add_recipe(rec_svm) |> 
  add_model(svmrb_model_tune)

# Definir los parámetros de ajuste
svmrb_wf_tune_param  <- extract_parameter_set_dials(svmrb_wf_tune)

# Crear grid para los parámetros a ajustar
grid_svmrb_wf_tune <- expand.grid(
  cost = cost() |> value_seq(n = 10, original = TRUE),
  rbf_sigma = rbf_sigma() |> value_seq(n = 10, original = TRUE)
)

## Validación cruzada para encontrar el mejor hiperparámetro
set.seed(101112)
k1 <- 5; k2 <- 1
data_cvrep_tune <- rsample::vfold_cv(data_train, v = k1, repeats = k2)
ctrl <- control_resamples(event_level = "second")

# Paralelización y tuning
library(parallel)
library(doParallel)

cl <- makePSOCKcluster(8)
registerDoParallel(cl)

svmrb_reg_tune <- tune_grid(
  svmrb_wf_tune,
  resamples = data_cvrep_tune,
  grid = grid_svmrb_wf_tune,
  metrics = metricas, 
  control = ctrl
)

stopCluster(cl)

svmrb_reg_tune |>
  collect_metrics()

## Selección del mejor hiperparámetro
svmrb_reg_tune |>
  show_best(metric = "roc_auc")
best_svmrb_reg_tune <- svmrb_reg_tune |>
  select_best(metric = "roc_auc")

# Finalizar el workflow con el mejor hiperparámetro
finalwf_svmrb <- svmrb_wf_tune |>
  finalize_workflow(best_svmrb_reg_tune)


# Filtrar las métricas correspondientes al mejor modelo

svmrbf_metrics_best <- svmrb_reg_tune |>
  collect_metrics() |>  # Recopilar todas las métricas
  filter(cost == best_svmrb_reg_tune$cost, rbf_sigma == best_svmrb_reg_tune$rbf_sigma)
print (svmrbf_metrics_best)



# Nueva validación cruzada con otro conjunto de training
set.seed(202201)
data_cvrep_new <- rsample::vfold_cv(data_train, v = 5, repeats = 10)
ctrl <- control_grid(event_level = "second", save_pred = TRUE) 
cl <- makePSOCKcluster(4)
registerDoParallel(cl)

asses_finalwf_svmrb <-
  fit_resamples(finalwf_svmrb,
                resamples = data_cvrep_new,
                metrics = metricas,
                control = ctrl)

stopCluster(cl)
collect_metrics(asses_finalwf_svmrb)

## ENTRENAMIENTO FINAL CON AJUSTE DE UMBRAL--------------------------------------------------------------------------------------------------------------------------
final_model <- fit(finalwf_svmrb, data_train)
prob_preds <- predict(final_model, data_test, type = "prob") |>
  bind_cols(predict(final_model, data_test)) |>
  bind_cols(data_test %>% select(patient_id, Insuficiencia_Renal_Real = `Insuficiencia Renal`))

# Aplicar umbral y crear predicción binaria
umbral <- 0.2434532
prob_preds <- prob_preds %>%
  mutate(.pred_class_custom = if_else(.pred_1 >= umbral, "1", "0") %>%
           factor(levels = c("0", "1")))

head(prob_preds)

library(yardstick)
library(dplyr)

# Asegúrate de que las variables estén en el formato correcto
prob_preds <- prob_preds %>%
  mutate(
    Insuficiencia_Renal_Real = factor(Insuficiencia_Renal_Real, levels = c("0", "1")),
    .pred_class_custom = factor(.pred_class_custom, levels = c("0", "1"))
  )

# Crear tabla con truth, predicción binaria y probabilidad para métricas
metrics_data <- prob_preds %>%
  select(Insuficiencia_Renal_Real, .pred_class_custom, .pred_1)

# Definir métricas a calcular
metricas_clasicas <- metric_set(accuracy, sens, specificity, precision, f_meas, detection_prevalence, j_index)

# Calcular métricas categóricas usando la predicción ajustada por umbral
metricas_test <- metricas_clasicas(metrics_data,
                                   truth = Insuficiencia_Renal_Real,
                                   estimate = .pred_class_custom,
                                   event_level = "second")

# Calcular AUC con probabilidades continuas
roc_auc_test <- roc_auc(metrics_data,
                        truth = Insuficiencia_Renal_Real,
                        .pred_1,
                        event_level = "second")

# Combinar y mostrar resultados
resultados <- bind_rows(metricas_test, roc_auc_test)
print(resultados)

# --- Extraer y procesar predicciones de validación cruzada (CV) ---
cv_preds <- collect_predictions(asses_finalwf_svmrb) %>%
  mutate(
    .pred_class_custom = if_else(.pred_1 >= umbral, "1", "0") %>%
      factor(levels = c("0", "1")),
    `Insuficiencia Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1"))
  )

# --- Calcular métricas clásicas en CV ---
metricas_cv <- metricas_clasicas(cv_preds,
                                 truth = `Insuficiencia Renal`,
                                 estimate = .pred_class_custom,
                                 event_level = "second")

# --- Calcular AUC en CV ---
roc_auc_cv <- roc_auc(cv_preds,
                      truth = `Insuficiencia Renal`,
                      .pred_1,
                      event_level = "second")

# --- Mostrar métricas CV ---
resultados_cv <- bind_rows(metricas_cv, roc_auc_cv)
cat("Métricas en Validación Cruzada:\n")
print(resultados_cv)


#### CURVA LIFT CON SVM RADIAL ####----------------------------------------------------------------------------------------------------------

# Cargar librerías necesarias
library(dplyr)
library(ggplot2)

# Ordenar por probabilidad descendente (mayor riesgo a menor)
lift_data <- prob_preds %>%
  arrange(desc(.pred_1)) %>%
  mutate(rank = row_number(),
         percentile = ntile(rank, 10))  # Dividir en 10 deciles

# Calcular tasa global positiva (base rate)
base_rate <- mean(as.numeric(as.character(lift_data$Insuficiencia_Renal_Real)))

# Calcular lift por decil
lift_summary <- lift_data %>%
  group_by(percentile) %>%
  summarise(
    n = n(),
    positives = sum(as.numeric(as.character(Insuficiencia_Renal_Real))),
    positive_rate = positives / n
  ) %>%
  mutate(lift = positive_rate / base_rate,
         percentile_label = percentile * 10)

# Graficar curva lift
ggplot(lift_summary, aes(x = percentile_label, y = lift)) +
  geom_line() +
  geom_point() +
  geom_hline(yintercept = 1, linetype = "dashed", color = "red") +
  labs(
    title = "Curva Lift - SVM RADIAL",
    x = "Percentil acumulado (%)",
    y = "Lift (Tasa positiva / Tasa base)"
  ) +
  theme_minimal()









## ENTRENAMIENTO FINAL ANTIGUO ---------------------------------------------------------------------

umbral_optimo <- 0.2434532
ctrl = control_last_fit(event_level = "second")

modelo_final <- fit(finalwf_rf, data = data_train)

# 2. Predicciones sobre TRAIN
predicciones_train <- predict(modelo_final, data_train, type = "prob") |> 
  bind_cols(data_train) |> 
  mutate(
    clase_ajustada = factor(ifelse(.pred_1 >= umbral_optimo, "1", "0"), levels = c("0", "1")),
    `Insuficiencia Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1"))
  )

# 3. Predicciones sobre TEST
predicciones_test <- predict(modelo_final, data_test, type = "prob") |> 
  bind_cols(data_test) |> 
  mutate(
    clase_ajustada = factor(ifelse(.pred_1 >= umbral_optimo, "1", "0"), levels = c("0", "1")),
    `Insuficiencia Renal` = factor(`Insuficiencia Renal`, levels = c("0", "1"))
  )

# 4. Métricas categóricas (sin ROC)
metricas_clasicas <- metric_set(accuracy, sens, specificity, precision, f_meas, detection_prevalence, j_index)

metricas_train <- metricas_clasicas(predicciones_train, 
                                    truth = `Insuficiencia Renal`, 
                                    estimate = clase_ajustada, 
                                    event_level = "second")

metricas_test <- metricas_clasicas(predicciones_test, 
                                   truth = `Insuficiencia Renal`, 
                                   estimate = clase_ajustada, 
                                   event_level = "second")

# 5. AUC (ROC) por separado
roc_auc_train <- roc_auc(predicciones_train, 
                         truth = `Insuficiencia Renal`, 
                         .pred_1, 
                         event_level = "second")

roc_auc_test <- roc_auc(predicciones_test, 
                        truth = `Insuficiencia Renal`, 
                        .pred_1, 
                        event_level = "second")

# 6. Mostrar resultados
cat("MÉTRICAS EN TRAIN:\n")
print(bind_rows(metricas_train, roc_auc_train))

cat(" MÉTRICAS EN TEST:\n")
print(bind_rows(metricas_test, roc_auc_test))









